**MODUL PRAKTIKUM APLIKASI WEB**

**PERTEMUAN 3**

**ARSITEKTUR INFORMASI, USER FLOW, WIREFRAME, DAN PROTOTIPE AWAL**

*Mengubah Backlog Menjadi Rancangan Antarmuka yang Dapat Diuji*

| Identitas | Keterangan |
| ----- | ----- |
| Mata Kuliah | Praktik Aplikasi Web |
| Kode | INF60295 |
| Semester | 5 |
| Dosen Pengampu | Zaenal Mustofa, M.Kom. |
| Program Studi | Teknologi Informasi \- S1 |
| Durasi | 200 menit |

Prinsip modul: setiap kelompok mengubah user story prioritas menjadi sitemap, user flow, wireframe responsif, dan prototipe awal yang dapat diperiksa.

FAKULTAS TEKNIK \- UNIVERSITAS NEGERI YOGYAKARTA  
PROGRAM STUDI TEKNOLOGI INFORMASI • YOGYAKARTA • 2026

# **MODUL PRAKTIKUM PERTEMUAN 3**

Praktikum ini menerjemahkan persona, user story, acceptance criteria, dan backlog dari Pertemuan 2 menjadi rancangan halaman yang memiliki alur jelas, responsif, dan siap menjadi acuan implementasi aplikasi web.

## **A. Capaian Praktikum**

* Memilih user story prioritas sebagai ruang lingkup prototipe.  
* Menyusun arsitektur informasi dan sitemap aplikasi.  
* Menggambar user flow untuk satu proses layanan utama.  
* Membuat wireframe low-fidelity untuk desktop dan mobile.  
* Menyusun prototipe klik sederhana serta melakukan usability walkthrough.  
* Mendokumentasikan keputusan desain dan mengunggah hasil ke repositori proyek.

## **B. Prasyarat dan Perangkat**

* Hasil Pertemuan 2: persona, minimal delapan user story, acceptance criteria, dan backlog prioritas.  
* Laptop/PC dan browser modern.  
* Figma, Penpot, diagrams.net, atau aplikasi desain lain yang disepakati.  
* Akun GitHub dan repositori proyek kelompok.  
* Folder proyek serta koneksi internet.

## **C. Istilah Kunci**

| Istilah | Pengertian Singkat |
| ----- | ----- |
| Arsitektur informasi | Susunan konten, halaman, label, dan navigasi agar pengguna mudah menemukan informasi. |
| Sitemap | Peta hierarki halaman dalam aplikasi. |
| User flow | Urutan langkah pengguna untuk mencapai satu tujuan. |
| Wireframe | Sketsa struktur halaman tanpa fokus pada warna dan dekorasi. |
| Prototype | Simulasi antarmuka yang menghubungkan beberapa layar. |
| Responsive design | Rancangan yang menyesuaikan ukuran dan karakteristik layar. |
| Usability walkthrough | Pemeriksaan langkah demi langkah untuk menilai apakah tugas mudah diselesaikan. |

## **D. Alokasi Waktu 200 Menit**

| Kegiatan | Waktu |
| ----- | ----- |
| Orientasi dan pemeriksaan backlog | 15 menit |
| Menentukan ruang lingkup dan navigasi | 25 menit |
| Menyusun sitemap | 25 menit |
| Membuat user flow | 30 menit |
| Membuat wireframe desktop dan mobile | 60 menit |
| Menyusun prototipe dan usability walkthrough | 30 menit |
| Revisi, refleksi, dan pengumpulan | 15 menit |

# **HUBUNGAN PERTEMUAN 2 DAN PERTEMUAN 3**

| Artefak Pertemuan 2 | Dipakai untuk | Artefak Pertemuan 3 |
| ----- | ----- | ----- |
| Persona | Menentukan konteks, perangkat, kebutuhan, dan hambatan pengguna. | Keputusan layout dan prioritas informasi |
| User story | Menentukan tindakan yang harus didukung antarmuka. | Daftar layar dan user flow |
| Acceptance criteria | Menentukan kondisi normal, validasi, dan kegagalan. | State layar dan pesan sistem |
| Backlog prioritas | Membatasi fitur yang dirancang terlebih dahulu. | Ruang lingkup prototipe |
| Peer review | Mengidentifikasi asumsi yang perlu diuji. | Pertanyaan usability walkthrough |

## **Studi Kasus Utama**

Kelompok melanjutkan aplikasi “Sistem Peminjaman Ruang dan Peralatan Kampus”. Alur utama mahasiswa meliputi masuk, mencari ruang, memilih hasil, mengisi pengajuan, dan memantau status. Petugas meninjau pengajuan serta mengubah status. Kelompok yang memakai ide lain tetap mengikuti struktur pekerjaan yang sama.

## **Output Wajib**

* Daftar user story yang masuk ruang lingkup Pertemuan 3\.  
* Sitemap aplikasi dan daftar halaman.  
* Minimal dua user flow: satu pengguna utama dan satu petugas/admin.  
* Wireframe desktop minimal empat layar.  
* Wireframe mobile minimal empat layar yang berpasangan dengan versi desktop.  
* Prototipe klik untuk satu happy path dan satu kondisi gagal.  
* Catatan usability walkthrough, revisi, serta tautan repositori/desain.

# **PRAKTIKUM 1 \- MENENTUKAN RUANG LINGKUP DESAIN**

## **Tujuan Praktik**

Memilih bagian produk yang paling bernilai dan cukup kecil untuk dirancang dalam satu pertemuan.

## **Tutorial Langkah demi Langkah**

1. Buka backlog Pertemuan 2 dan urutkan story berprioritas Must.  
2. Pilih satu tujuan utama pengguna yang dapat diselesaikan dari awal sampai akhir.  
3. Pilih 3-5 user story yang mendukung tujuan tersebut.  
4. Salin acceptance criteria yang relevan.  
5. Tentukan batas prototipe: halaman yang dibuat dan fitur yang belum dibuat.  
6. Tuliskan risiko atau asumsi yang perlu diperiksa melalui prototipe.

## **Contoh Ruang Lingkup**

| ID | User Story Ringkas | Masuk? | Alasan |
| ----- | ----- | ----- | ----- |
| US-01 | Melihat ruang tersedia berdasarkan tanggal dan kapasitas | Ya | Awal proses layanan |
| US-02 | Melihat detail fasilitas ruang | Ya | Dibutuhkan sebelum memilih |
| US-03 | Mengajukan peminjaman | Ya | Tujuan utama pengguna |
| US-04 | Menerima notifikasi email | Belum | Dapat disimulasikan sebagai status |
| US-05 | Menyimpan ruang favorit | Tidak | Prioritas Could |

## **Lembar Kerja 1 \- Scope Canvas**

| Tujuan Pengguna | User Story Terpilih | Halaman yang Dibutuhkan | Di Luar Ruang Lingkup | Asumsi yang Diuji |
| ----- | ----- | ----- | ----- | ----- |
|  |  |  |  |  |
|  |  |  |  |  |

# **PRAKTIKUM 2 \- ARSITEKTUR INFORMASI DAN SITEMAP**

## **Tujuan Praktik**

Menyusun halaman dan navigasi sehingga informasi mudah ditemukan oleh setiap peran.

## **Prinsip Arsitektur Informasi**

* Gunakan istilah yang dipahami pengguna, bukan nama teknis internal.  
* Kelompokkan konten berdasarkan tugas dan kebutuhan pengguna.  
* Sediakan jalur singkat menuju tindakan utama.  
* Bedakan menu publik, pengguna terautentikasi, dan petugas/admin.  
* Jangan membuat halaman terpisah bila kontennya dapat disajikan sebagai state atau komponen.

## **Tutorial Menyusun Sitemap**

7. Daftar semua halaman dari user story terpilih.  
8. Kelompokkan halaman berdasarkan peran dan fungsi.  
9. Tentukan halaman awal untuk pengguna yang belum masuk.  
10. Susun hierarki maksimal tiga tingkat untuk prototipe awal.  
11. Tambahkan halaman utilitas: masuk, profil, bantuan, dan not found bila relevan.  
12. Periksa apakah setiap halaman memiliki jalur masuk dan jalur kembali.

## **Contoh Sitemap**

| Level 1 | Level 2 | Level 3 / State |
| ----- | ----- | ----- |
| Beranda | Cari Ruang | Hasil kosong / hasil tersedia |
|  | Detail Ruang | Tersedia / tidak tersedia |
| Pengajuan | Form Pengajuan | Validasi / konfirmasi |
|  | Riwayat | Menunggu / disetujui / ditolak |
| Akun | Profil | Ubah data |
| Petugas | Daftar Pengajuan | Detail / ubah status |

## **Lembar Kerja 2 \- Daftar Halaman**

| ID Halaman | Nama Halaman | Peran | Tujuan | Sumber User Story | Navigasi Masuk/Keluar |
| ----- | ----- | ----- | ----- | ----- | ----- |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

# **PRAKTIKUM 3 \- MEMBUAT USER FLOW**

## **Tujuan Praktik**

Menggambarkan langkah pengguna, keputusan, validasi, dan hasil akhir untuk satu tujuan.

![][image1]

Gambar 1\. Contoh happy path peminjaman ruang

## **Tutorial Langkah demi Langkah**

13. Tentukan titik mulai dan tujuan akhir.  
14. Tuliskan aksi pengguna dengan kata kerja: memilih, mengisi, mengirim, atau membatalkan.  
15. Tambahkan respons sistem setelah setiap aksi penting.  
16. Tambahkan decision point, misalnya ruang tersedia atau tidak.  
17. Gambar happy path terlebih dahulu, kemudian jalur gagal atau alternatif.  
18. Cocokkan setiap langkah dengan acceptance criteria.  
19. Pastikan alur dapat selesai tanpa jalan buntu.

## **Lembar Kerja 3 \- Skenario Flow**

| Langkah | Aktor | Aksi | Respons Sistem | Keputusan/Kondisi | Layar |
| ----- | ----- | ----- | ----- | ----- | ----- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |
| 6 |  |  |  |  |  |

# **PRAKTIKUM 4 \- MEMBUAT WIREFRAME RESPONSIF**

## **Tujuan Praktik**

Menerjemahkan sitemap dan user flow menjadi struktur layar desktop dan mobile yang mudah dipahami.

![][image2]

Gambar 2\. Contoh wireframe halaman pencarian ruang

## **Aturan Wireframe Low Fidelity**

* Gunakan warna abu-abu atau satu warna aksen; fokus pada struktur.  
* Tampilkan hierarki informasi melalui ukuran, posisi, dan jarak.  
* Gunakan label nyata, bukan seluruhnya lorem ipsum.  
* Sediakan state kosong, loading, validasi, sukses, dan gagal bila dibutuhkan acceptance criteria.  
* Pastikan tombol utama terlihat dan memiliki label tindakan.  
* Jangan bergantung pada hover untuk fungsi penting pada layar sentuh.

## **Tutorial Desktop**

20. Buat frame desktop lebar 1440 px atau ukuran setara.  
21. Susun header, navigasi, konten utama, dan footer seperlunya.  
22. Tempatkan aksi utama di area yang mudah ditemukan.  
23. Buat komponen berulang: field, button, card, modal, dan status.  
24. Hubungkan setiap elemen dengan user story atau acceptance criteria.

## **Tutorial Mobile**

25. Buat frame mobile lebar sekitar 360-390 px.  
26. Ubah navigasi lebar menjadi pola yang sesuai layar kecil.  
27. Susun konten dalam satu kolom dan pertahankan urutan prioritas.  
28. Pastikan target sentuh cukup besar dan tidak berdekatan.  
29. Periksa tidak ada konten penting yang hanya terlihat di desktop.

## **Lembar Kerja 4 \- Inventaris Layar**

| Layar | Tujuan | Komponen Utama | State Wajib | Versi Desktop | Versi Mobile |
| ----- | ----- | ----- | ----- | ----- | ----- |
| Beranda/Cari |  |  |  | □ | □ |
| Hasil Pencarian |  |  |  | □ | □ |
| Detail |  |  |  | □ | □ |
| Form Pengajuan |  |  |  | □ | □ |
| Status/Riwayat |  |  |  | □ | □ |
| Layar Petugas |  |  |  | □ | □ |

## **Pemeriksaan Keterhubungan**

| User Story ID | Acceptance Criteria | Layar/Komponen | State yang Membuktikan AC |
| ----- | ----- | ----- | ----- |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

# **PRAKTIKUM 5 \- PROTOTIPE DAN USABILITY WALKTHROUGH**

## **Tujuan Praktik**

Menghubungkan layar menjadi simulasi dan memeriksa apakah pengguna dapat menyelesaikan tugas tanpa penjelasan dari perancang.

## **Membuat Prototipe Klik**

30. Pilih frame awal.  
31. Hubungkan tombol dan area klik ke layar tujuan.  
32. Buat satu happy path dari awal sampai hasil akhir.  
33. Tambahkan satu kondisi gagal, misalnya input belum lengkap atau ruang tidak tersedia.  
34. Aktifkan tombol kembali atau cara keluar yang jelas.  
35. Jalankan prototype preview dan perbaiki tautan yang salah.

## **Skenario Pengujian**

Anda adalah ketua panitia yang membutuhkan ruang untuk 50 peserta pada tanggal tertentu. Temukan ruang yang sesuai, periksa fasilitas, ajukan peminjaman, lalu pastikan status pengajuan dapat ditemukan kembali.

## **Aturan Walkthrough**

* Penguji tidak boleh menerima petunjuk langkah dari perancang.  
* Penguji mengucapkan apa yang dipikirkan selama mencoba.  
* Pengamat mencatat titik ragu, salah klik, istilah membingungkan, dan jalan buntu.  
* Tim membedakan masalah kritis, mayor, dan minor.  
* Perbaiki minimal tiga masalah yang paling berpengaruh.

## **Lembar Kerja 5 \- Hasil Uji**

| No. | Langkah/Tugas | Temuan | Keparahan | Perbaikan | Status |
| ----- | ----- | ----- | ----- | ----- | ----- |
| 1 |  |  | Kritis/Mayor/Minor |  | Belum |
| 2 |  |  | Kritis/Mayor/Minor |  | Belum |
| 3 |  |  | Kritis/Mayor/Minor |  | Belum |
| 4 |  |  | Kritis/Mayor/Minor |  | Belum |
| 5 |  |  | Kritis/Mayor/Minor |  | Belum |

# **PRAKTIKUM 6 \- DOKUMENTASI DAN VERSION CONTROL**

## **Struktur Folder Pertemuan 3**

Pertemuan03/  
├── 01-scope-canvas.pdf  
├── 02-sitemap.pdf  
├── 03-user-flow-pengguna.pdf  
├── 04-user-flow-admin.pdf  
├── 05-wireframe-desktop.pdf  
├── 06-wireframe-mobile.pdf  
├── 07-usability-walkthrough.pdf  
├── 08-keputusan-desain.md  
└── README.md

## **Langkah Git**

36. Buat folder Pertemuan03 di repositori proyek.  
37. Tambahkan seluruh artefak atau tautan desain pada README.md.  
38. Tuliskan nama anggota dan kontribusinya.  
39. Gunakan pesan commit yang menjelaskan perubahan, misalnya: docs: add sitemap and responsive wireframes.  
40. Push ke branch kelompok dan pastikan tautan dapat dibuka.  
41. Buat tag atau release milestone-pertemuan-3 jika disepakati dosen.

## **Format Keputusan Desain**

| Keputusan | Dasar Persona/User Story | Alternatif | Alasan Dipilih | Perlu Diuji Lagi? |
| ----- | ----- | ----- | ----- | ----- |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

# **PENILAIAN, REFLEKSI, DAN PENGUMPULAN**

## **E. Rubrik Penilaian Praktikum**

| Aspek | Bobot | Indikator |
| ----- | ----- | ----- |
| Keterhubungan dengan backlog | 15% | Scope dan layar dapat ditelusuri ke persona, user story, dan acceptance criteria. |
| Arsitektur informasi dan sitemap | 15% | Hierarki, label, navigasi, dan pembagian peran jelas. |
| User flow | 20% | Happy path, keputusan, kondisi gagal, dan hasil sistem lengkap tanpa jalan buntu. |
| Wireframe responsif | 25% | Hierarki informasi jelas; desktop dan mobile konsisten; state penting tersedia. |
| Prototype dan usability | 15% | Prototipe dapat dijalankan; temuan uji tercatat; revisi didasarkan pada bukti. |
| Dokumentasi dan kolaborasi | 10% | Repositori rapi; kontribusi anggota serta keputusan desain tercatat. |

## **F. Ketentuan Pengumpulan**

* Kumpulkan satu tautan repositori dan satu tautan prototipe per kelompok.  
* Pastikan dosen dapat membuka tautan tanpa meminta izin tambahan.  
* Gunakan struktur folder yang ditentukan.  
* Cantumkan anggota, kelas, nama proyek, dan tanggal revisi.  
* Setiap mahasiswa mengumpulkan refleksi individu.

## **G. Refleksi Individu**

42. Keputusan desain apa yang paling kuat kaitannya dengan persona?  
43. Bagian user flow mana yang berubah setelah dibuat wireframe?  
44. Apa perbedaan terpenting antara layout desktop dan mobile?  
45. Temuan usability apa yang paling berpengaruh?  
46. Apa kontribusi Anda dan bukti commit atau artefaknya?

# **TROUBLESHOOTING, REFERENSI, DAN CHECKLIST**

## **H. Troubleshooting**

| Masalah | Penyebab Umum | Solusi |
| ----- | ----- | ----- |
| Sitemap terlalu besar | Semua backlog dimasukkan sekaligus. | Batasi pada story Must dan tujuan utama pertemuan. |
| User flow hanya daftar halaman | Tidak memuat aksi, respons, dan keputusan. | Tambahkan aktor, aksi, respons sistem, decision point, dan hasil. |
| Wireframe menjadi desain visual rinci | Terlalu cepat memilih warna dan ilustrasi. | Kembali ke hierarki, konten, navigasi, dan state. |
| Versi mobile hanya diperkecil | Tidak mengubah struktur untuk layar sempit. | Susun ulang prioritas, navigasi, dan target sentuh. |
| Prototype jalan buntu | Tautan atau jalur kembali belum dibuat. | Uji semua hotspot dari frame awal hingga akhir. |
| Pengujian tidak menghasilkan temuan | Penguji diberi terlalu banyak petunjuk. | Gunakan task scenario dan observasi tanpa mengarahkan. |
| Tautan tidak dapat dibuka | Hak akses masih privat. | Uji tautan menggunakan jendela incognito sebelum mengumpulkan. |

## **I. Referensi**

1\. Garrett, J. J. (2011). The Elements of User Experience. New Riders.

2\. Krug, S. (2014). Don’t Make Me Think, Revisited. New Riders.

3\. Tidwell, J., Brewer, C., & Valencia, A. (2020). Designing Interfaces (3rd ed.). O’Reilly Media.

4\. Wroblewski, L. (2011). Mobile First. A Book Apart.

5\. Nielsen, J. (1994). Usability Engineering. Morgan Kaufmann.

6\. ISO 9241-210:2019. Ergonomics of human-system interaction \- Human-centred design for interactive systems.

7\. Marcotte, E. (2011). Responsive Web Design. A Book Apart.

## **J. Checklist Akhir**

* □ Scope menggunakan backlog dan user story prioritas.  
* □ Sitemap memisahkan kebutuhan pengguna dan petugas/admin.  
* □ Dua user flow memiliki titik mulai, tujuan, keputusan, dan kondisi gagal.  
* □ Minimal empat layar desktop dan empat layar mobile tersedia.  
* □ Acceptance criteria dapat ditelusuri ke layar atau state.  
* □ Prototype menjalankan happy path dan satu jalur gagal.  
* □ Walkthrough dilakukan oleh mahasiswa di luar perancang layar.  
* □ Minimal tiga temuan telah direvisi.  
* □ Repositori, tautan desain, dan kontribusi anggota dapat diperiksa.

Jembatan ke pertemuan berikutnya: wireframe dan prototype yang telah divalidasi akan digunakan untuk menyusun design system sederhana, struktur proyek, komponen tampilan, serta implementasi antarmuka awal.

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAogAAAC1CAIAAABTUJm3AAAPrUlEQVR4Xu3bi69lZXkHYP+YDRMI4TIGqExBtHSckXBrSbgMWHsJ9mqMWrXEFhVRubQVe4U2jbY2ta2VCEVTgzSh1t6IpbbF2lSwxipQOownNpHaZHUxH7O6WN/+Nvvynm8+Zj9PfjGLNWvWPue337XfOQO+rAMAmvGy6QkA4PixmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDLGYAaIjFDAANsZgBoCEWMwA0xGIGgIZYzADQEIsZABpiMQNAQyxmAGiIxQwADbGYAaAhFjMANMRiBoCGWMwA0BCLGQAaYjEDQEMsZgBoiMUMAA2xmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDLGYAaIjFDAANsZgBoCEWMwA0xGIGgIZYzADQEIsZABpiMQNAQyxmAGiIxQwADbGYAaAhFjMANMRiBoCGWMwA0BCLGQAaYjEDQEMsZgBoiMUMAA2xmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDAhbz/r0f2/JMG9kF+YtuW6aN7IL8Rbct00ai5a+4bZk2sgvyF922TBt5Cdp0MeelbGemvYTKX247M+0lTv5aW5tpNXHy19raTKuJk7/Wdmbay0vNRos5VbBz5H+3PLs6CkreOdbwLpU83Dx/3a2KkitEyRWyew1Xs/5iNgHj7MYoeMwm2b2S89fa2ii5QpS82xk+PKc1vUSsuZgNQZ7wOVBynt0oOX+VLU9sw52S5yW2ZJ8VecI/K2pafzHnRUjsHCg5T+zD5uNsbpRcIUqukNiSa1pnMRuCUgLnQMmlKLlCohru/PmyEGNcIYElV2YxRyZwDpRcipIrJKrhzmIuxBhXSGDJlVnMkQmcAyWXouQKiWq4s5gLMcYVElhyZRZzZALnQMmlKLlCohruLOZCjHGFBJZcmcUcmcA5UHIpSq6QqIY7i7kQY1whgSVXZjFHJnAOlFyKkiskquHOYi7EGFdIYMmVWcyRCZwDJZei5AqJarizmAsxxhUSWHJlFnNkAudAyaUouUKiGu4s5kKMcYUEllyZxRyZwDlQcilKrpCohjuLuRBjXCGBJVdmMUcmcA6UXIqSKySq4c5iLsQYV0hgyZVZzJEJnAMll6LkColquLOYCzHGFRJYcmUWc2QC50DJpSi5QqIa7izmQoxxhQSWXJnFHJnAOVByKUqukKiGO4u5EGNcIYElV2YxRyZwDpRcipIrJKrhzmIuxBhXSGDJlVnMkQmcAyWXouQKiWq4s5gLMcYVElhyZRZzZALnQMmlKLlCohruLOZCjHGFBJZcWUOLeXbU2Wefk/7x8a88kc7ceONN+cVrpL/VnR/89fx8YALnYI2S+8ZOOumkVFqSX1PKueecu9L1xzHHq+Qffv2Pjbsd6hpXNxvN2HCcLtjt2YtNVMNdYTGPC8zTTmO792XUH+O883HPK3We32px+ovPP/+C/Pw4t9/2wZXuuUwCS66sucXc+9Yz3+3/8eV7X57+8cRezDt/OP8tWLXkL3/pa6mui197yeGnv3P/fQ+cfPKe/LITIMer5GExHzn87I+/4af6g4MHL55cM3fGVvrIaySrNrzA3IZTk/n57ckaY1yy5Bgv7nylKV18qzwzi3lF8z+wFltyDlZNerN71157ffrHa64+NBst5uGC3r2f/LP85OWX/+Bw5uN/dG9//IYbfnKW/TRz4YWv7o8f/afH8q9hw6wxB/3OmLs2Vi05fdfnnbdvcr4v8/l2jhpf37eRfsLeKf/EPL7siW/szI4Vm36p31XD8WDuWzMb3fy6Q69LZy679Ir+fy+55LL8dRfkeJU8LOb0j8Pxkj8xv+Pt70y/Zbh4nHTxuOfxPZfpef/+A+ngjW98czq/Sc+rNtwtLDm/f/rC+oMjh/8nHSfpES4tif7k295243Bx/yekdP7UU08dTt5914fHLzGYvPTshbVMHpNxt+nLSOfTycmnyuCM089IJ9PXP7wjs3nv+Bpj3BX+iLnkGOdfSf4Tcz6lwz/OjtWSvv3B5FV+9EduGH5p/IE8mJxJpU3umT8C6XgyLZOXzrNeyS2Y8za/qCXnYNWkrt//vtv7/73nE59Kvc/m/cQ8flf6g0/e8+n8Vz/xJ/fvZI/Qu991S/rVrz725OSeIVljDtLHWf6htmrJ6fv6539c9KeN/oIrr7xqOO7XwPBLCxbzcFl6WlKx6ZeGhTG+frjP5PiKK557St9786398V9//pH++B/+/suzFRfGzvErOf+J+cCB1+4svZj75dEfX3/964eLx5llPY/vmff88+989/iC3uNfeWI43tm451Ub7haWnN9/+DpvuOEnZtkjvGAxD8tv8p2mk6+84ML++Dd/43fGF6Tj5cdv8hsXL+Yh6R1Jz1f6+tM7UnrH1xjjrlDykmM8/hZS8sW8YErzkZtcMPzS5N1MJ+f+xDy+5/gn5vwRSMdpWvL7lLJeyS1objEPB3fcfmc6Tov5mf96Np0fjH9X8rmHHh7OzF3MySNf+Jf81UOyxhyMn7Q1HrYh6Vv78wf/anI+rZDBued+z3D9u266ZbhswWIeList5sVvzXB80fd9f39w0UX7h5PpfP7JuDjHq+QN/x1zvxL645t+4b3DxePMsp7H91yp53S8Yc+rNtwtLDm///B1Dv8KJkmP8ILF/L5bbpvcYd++88d36B269nXjC9Lx4vGbPCbj37h4MY9/y+zY8zUeidI7vsYYd4WSlxzj9BWOz+SLeTKly4zcJGeeedZwcXo30/XDYi7dc5nFPJmWyUvnWa/kFrS4mK+/7oeG0mfHFvOll17eH3/6Uw+Or0y5/74HfvatPzecTAcf/b0/7o8vuOCV41sNn61f/9rh8UtH5blaXvjkbJKVSk7f177zvnfu+W98/Zl03D9+w/nxB9+CxTxc9tQT354dKzb9UloYpbdmcpw+Ga++6trxC81WXBg7oSWvNMmTv8oesuRiTsfp72wmd5j8xtTz+J55z+MfEycXp+MNe44tOb//+GveyR7hBYv5Z376TZM7XH7ZD4xvNb54OD97sfFLF8+d4XwxTz5VXvGK8/rnK70j6fkaj0TpHX9+9rK61svckicZfwsp+WKeTOkyI5dn8m6m64fFnO7Zlza553gx54/A+OV+5UN3pZvc/J73DyfnxmIOyKT94WRazLfd+svpgsH4d41P/uIdH8pPpivHz9jhp78zea3NE/ik7Sz3sI1z9tnnvODbPvqNT85sspjzu6WFsfitGY7TJ2N+k5UWxk5oyStNcrXFnP5xbKWeJ8eDlXqOLTm/f/qSdo59HI/tLFzMY7d+4Jfmnp/8rX46Xjx+k5Oz7A1d8Kky1v5iHjz42c+/6GJePHLjM6VXyU+W7vm3f/PF8ZnRr///ycm03HfvZyavPonFHJCh/cnJ4d8xX3TR/tNPP314b9LJ/uHsH7mTT97z1re8Y/hd/R/ETjnllI/9wT1z/+Ovbz3z3XSH9J9/BybwSdtZ7mGb5IuP/Os111y3Z8+eyy694v4/faA/859Pfrvv7eDBi9PfDm24mL/5H0f6Yq+5+lDqcPh3n3Pfmsnx8Ml45PCzp512Wv8V9n82mh37i8flE1jySpNcczH3Pb/qVa9e0PP4x4vxVzU+3qTn2JLz+w9f59NP/Xf+CC9YzP3JO26/s/++fv+jHx/OP/Zv3+y76iez/0Hqdz/y/MtNahnG77fv/kheS3pM+m7zv0T9tV/9rXTcf6qcddbeyadK/0b0r9s/X+kdOcEW887RbzAfub6uA685mO4zeZXPPvCX6d3sLxhO9su473y4PpU2uWef8T0nj0A6maZl7969Z5xx5vgDvxSLWZ7LGnMwecCG8ydwyVdeedW/P/7U4489mf6z1b946O/yaxZEyUtmk55XbbhbWHJ+//Uym7etV83dd314yVrSX7R+4eFH81/aPGuMcbfZf/y1hVmv5BZYzJFZYw7yxyw5gUv+3EMP79t3fv8n6OsOrfAz3BAlL5lxz1969Kv5BQuyasPdiv93qfUSsphvfs8Hlhm/1+w/sGfPnre8+e35L4VkjTHuCiWf2GO8SdYruQXT93gZ5qCUNeZg7pPWKbmc9UqenjpKyaWs2nC3sOT8/rLGGHeFko1xKeuV3II5b/OLMgelBM6BkktRcoVENdxZzIUY4woJLLkyizkygXOg5FKUXCFRDXcWcyHGuEICS67MYo5M4BwouRQlV0hUw53FXIgxrpDAkiuzmCMTOAdKLkXJFRLVcGcxF2KMKySw5Mos5sgEzoGSS1FyhUQ13FnMhRjjCgksuTKLOTKBc6DkUpRcIVENdxZzIca4QgJLrsxijkzgHCi5FCVXSFTDncVciDGukMCSK7OYIxM4B0ouRckVEtVwZzEXYowrJLDkyizmyATOgZJLUXKFRDXcWcyFGOMKCSy5Mos5MoFzoORSlFwhUQ13FnMhxrhCAkuuzGKOTOAcKLkUJVdIVMOdxVyIMa6QwJIrs5gjEzgHSi5FyRUS1XBnMRdijCsksOTKLObIBM6BkktRcoVENdxZzIUY4woJLLkyizkygXOg5FKUXCFRDXcWcyHGuEICS67MYo5M4BwouRQlV0hUw53FXIgxrpDAkiuzmCMTOAdKLkXJFRLVcGcxF2KMKySw5Mos5sgEzoGSS1FyhUQ13FnMhRjjCgksubJ1FnPnYSskdgiUnCf2SfOJNjdKrhAlV0hsyTWtv5jNwSThQ6DkPLEla3hulFwhSt7tpE4CS67JYg5L+BAoOY+SdzvhDXdKzhJecrqhkscJL7mmNRdzZxRGGaqYdrQxDQ/ZpYY7JY+i5ApRcoXsXsl1rL+Yu9Fu3tppGDcwbSeIkmuWnL/6lmS3G+6UrOTdz/Dt72rJFWy0mLsXro1tzrSXUPnLbWemvYTKX24LMy0lWv6KW5hpKaHyl9vOTHt5qdl0MQMAgSxmAGiIxQwADbGYAaAhFjMANMRiBoCGWMwA0BCLGQAaYjEDQEMsZgBoiMUMAA2xmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDLGYAaIjFDAANsZgBoCEWMwA0xGIGgIZYzADQEIsZABpiMQNAQyxmAGiIxQwADbGYAaAhFjMANMRiBoCGWMwA0BCLGQAaYjEDQEMsZgBoiMUMAA2xmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDLGYAaIjFDAANsZgBoCEWMwA0xGIGgIZYzADQEIsZABpiMQNAQyxmAGiIxQwADbGYAaAhFjMANMRiBoCGWMwA0BCLGQAaYjEDQEMsZgBoiMUMAA2xmAGgIRYzADTEYgaAhljMANAQixkAGmIxA0BDLGYAaIjFDAANsZgBoCEWMwA05P8AJQIFxwzxdLMAAAAASUVORK5CYII=>

[image2]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnoAAAFYCAIAAABLRMb7AAAvQklEQVR4Xu2deZQURb7v5905551z/3jvn7ecc999752597YLKO4rjojL9LjhjrLjoCKLCyIioKPOOMKAK6NPcUVwBBkEURiVccHRAREEhWEZBkWlZRNkoFhaRewX3UH/MjqiMruqIrKoLD6f8z2ezMjIrKyKX8Sns7rVHzUAAABAyvzIbgAAAIDQoFsAAIDUQbcAAACpg24BAABSB90CAACkDroFAABIHXQLAACQOugWAAAgddAtAABA6qBbAACA1EG3AAAAqYNuAQAAUgfdAgAApA66BQAASB10CwAAkDroFgAAIHXQLQAAQOqE123tMS8QQgghmY7tNm/QLSGEEGLHdps36JYQQgixY7vNG3RLCCGE2LHd5g26JYQQQuzYbvMG3RJCCCF2bLd5g24JIYQQO7bbvEG3hBBCiB3bbd6gW0IIIcSO7TZv0C0hhBBix3abN+iWEEIIsWO7zRt0SwghhNix3eYNuiWEEELs2G7zBt0SQgghdmy3eYNuCSGEEDu227ypCN3al2jCOvr5J9v07hU/m2F1uPnqt+Sss4+bIu2PjF4k7bql5/kzzV2V3972vvQR+nZ+zXxpvT24z5t6t0vty3JxuSvpLOcSQiokem5qLjltmtvBM+ccHy07RaXu85zc2O+fXKYbG0paRVtN4ZeVW9rz3V73qNu5x3kz1Ub/rq/rlu3bvr3wpy+6PTMX+RxCUUG61epaOG+D3r39+j+7R2vz6Xb3rj26RfHuG2ul3dTtuSf8odbRbe9Os/Tuhi93Dug6W/W5odcbDfl0e/sN7+rtSzpONy+Obgmp/Nw9dK7e+MOElatXbnU7eMZHt/relJ/0UpNeCr++fFx79/7wm+btuLiXRbdxVJxuZfeXN76b96irW7079p6FVrup221bv6l1dPv99z+o7RVLtsgpVnRneQL+aMFG6+LolpDKj/hjyvgV8975stZYChTiBmUX3VJrLLUP3r3AOvrdt/ue+dSGbpn14ie65e8rtuqWH34oaCUU3V506rSG5nVJb8yd8+UdgxrXQLX74nN/Uxt6V7do9L0tmr9h1Ih55rluH9ltKGCJlo9L3d4zDy+RN96p/dRdO7+T6/z8WFtI+ix0G0fF6VaebvMerXV0+/yTy2VXb1x7xb7vNES3g69q/LZZnWjpVm+fe2Ljg2/e6A4aVf3mIXRLSFYis3jV8q+l5eIOjd8qdzv7ZdFnQ77lSxrNDWUatbFpwy7dMq/l4qAy++U1Iq2EmF8mD+g6WzfqF7r60lfV8nLFWTPefu0LLe/PjNXG7Hn2cVP0Ru8LZinV5e1jbrQafee3Xf/nhqZPyTxRrj/l2ZXr1u6oNS7Ll8mtUkG6FXbu+O7S5u9s5WicbvX2H6c1/nT5j6/rG5ofZGsN3epu6lk2r27d25CSkhbFh+9vkJ5ycXRLSOVH+0OtKh8v3LT84821TbNVPbT9YDzOqsgjqRaYsO/o3h/0xtav6zuf8ZLa+NXNf9Etnc9s3FVZPH+jnPXso0t1Y0L0022X2pfV6mQ+vMrG6zPW9Dj3Fd2i/5n33tTp5530B7UAXnXJq3F9ZKPV6LM2rd/Zr0ujQc0n9dG/nG92k3/WotsCqCDdKnWpB033Onp3b3Oty69R1bZ8gWyhfiSsbanbKeNXqI31dTukpbb5y+QlH26S11KzqMHRbaeTp+oNOVFlxMB3Goy7ks7nnzRVWgghlRB50JRfkap/XnCKrQSZzm+9+rn+Dlb99CyzXo6Kbt2nW+m8Z8/ewnUr53Zq37h6yEX0s6/a+M3QuVMnrvzi0+21xr2ZPfX3urJw5b1/c/lKjvVcbq5y8jDzwvgVPN0WS2XpVm2rH/T0rv51hYr6aVS3PPjrBfLHTQ3NcyYv+lsXU7dWZ91y5YX7rqZeus/Ffzzn+CnD+jdK1NKt2jj3hH0/B6xZbT/OqrtSJ6q7lc6EkIqKnpuap3+3RLXoR0aN0qfuJl65pON0fUgtBQ3xunV/d6sErFvefu3zYnWrHh62fLW71hCYenqWP+xSjXcOfq/WuDeNXOqbb75Xi5jeznv/7ilxSdCt+Xep+ht1uSC6bZWK021t83fC5qWiqzdzz7B58oXJ4Kvekp7TJ63SjbWObsfcMV/vSovKfXd9II2Cq1uVnze/nP6ZTmXW1E+ic5pQdyVXJoSQssX8Q04SJNby7k8l6lYeJRfNj35d+uRDH29av3NH7jv1Y+N5JzX+cdN7b9a5ryhSrHV0Ky9knXL1pa9+8Jf16sq7dn63+IONnU6Ovg12O+uWrzbu+xJJ35X66U/9lKrvihBCypxuZzd+Kei2E5+IL0JREbolhBBSWm7tP+fbb7+/vuef3EPEJ7bbvEG3hBBCiB3bbd6gW0IIIcSO7TZv0C0hhBBix3abN+iWEEIIsWO7zRt0SwghhNix3eYNuiWEEELs2G7zBt0SQgghdmy3eYNuCSGEEDu227xBt4QQQogd223eoFtCCCHEju02b9AtIYQQYsd2mzfolhBCCLFju80bdEsIIYTYsd3mDbolhBBC7Nhu8wbdEkIIIXZst3mDbgkhhBA7ttu8SVG39gEAAICKJyWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBSGbgEAACJSUhi6BQAAiEhJYegWAAAgIiWFoVsAAICIlBRWubrdvXt3+/bta1oyceJEu19J6Kudc8459gEAg4EDB+pS+f7776WR4gGoboIozKVCdatXtLzYXUtCX4oVc38RdjTTA90CHID4Kywvlajbww47TJbjXbt2mYcqf4GGQpDxtQ9UGHl1CwDVjafC4qg43W7ZskXW4ksuucQ+bCDdhP79+5sdzj//fN2uHkTOO+88vT18+HA5N/kBRfqsWbNGbyu++eYb2Zael156qdUyatQo6aY5+OCDN23aJB0aWirH6Ggb6IwzzpBDZ511lgjA7amRo2+99Zbb3qFDB6ubkPDpXXfdddLt+eefN7stXLhQDtW0fC95FTV27Fije4TZ58wzzzQPdevWzTyqG81x0WO6d+/edu3aRac1Yf32IfnKitNOO02Orlq1Kq9udYtZPHKKYH2YAJAhfBSWQMXpdsiQIbJm2cdaYixuEWq5lA4ijJ/97GfSYdiwYXJuIbo1z63x0K1m27Zt0kca1aJvdKk59thjpc+XX35pHlL06NFDtqWbyaOPPqqPHnLIIdI4efJk3bh27VrdIhcxafXT0+RyOelmHfrpT38q2yXods+ePfaBJl555RW5gm6JG1MLU7fdu3e3DzchHVxby6ddrG5rWn6YAJAhfBSWQMXp1lzy7GMtqa+vN3flLLVk6xYRRk3T08b27duXLVt23333SedCdKuZP3/+zp07x40bV6BuH3/8cdlW7Nq1S3c44YQTpFGuo/jqq6/mzZsnu26fiy++WF1EPbBKS0385+N2UOq1Wor69JS0VH/1bK13r776at3no48+kj5z587dsWOH7NaUpFu5z927d+sWedyUK0TnNI2LNaZqgKSnYurUqXrjiy++0B0uuugi3aJ+9NEt6hFW7S5atEjvKq644gr1Xjp16iQtybo1P0wZ6xrjwwSADOGjsAQqTreyVNXE6yQvctbo0aN1iymMln3zrJguec8tULcu7lnSsmLFCt0yYMAA3aIfH5WD9a56ZJSzjjjiCDlRGi1mzJihO+iH6a1bt+rdhQsX2l2bkWsmf3pWi9vBfDzNq1uNe6Kirq4ub7tuka9n8/Yx248//vjbbrtN6T/v0bhG2TafSo866ijdmKxbC7mUfJgAkCF8FJZAxen29NNPl9XKPtYS96s/zaBBg3QHEcZJJ53U8tTWV8yG5j7WuQXqVj2cSTcL6eO2jBgxQrcoQapdJQy9e+utt0of9WTpnuiiO5x77rlqu1evXm7/wj+9jh07ylnSLe+u1VisbmfPni3tLqeeeqp5rjump5xySsszGvnyyy/1UftAS8wO5qd9zTXX6MZk3bb6YQJAhvBRWAIVp9vp06fLamU9oJjcfvvtxrLWghtvvFH3Mf/Yp+XZeVZMl7x98upWfmEpLdLHxe0jLfKmtG6XLVumd82/u7nsssvcE13kj5saml+od+/ecrTkT0+65d21GovV7YIFC6Td5eijjzbPzTt2M2fObHlSI/qQ3doSs8O1114rF+zcubNuTNBtIR8mAGQIH4UlUHG6bWi5MlqH1HqqN9wO0pIsDE1cu0lcH91ek++l9e4HH3ygd9VCHNcnb4ul27x9pMVszIvuM27cOL1h/lLTvYK0JH960k3vyi9WV65cqVvMJ9RidZvQbqI7uONioR5/zUuph+PkK3fo0EF3MPtIS4JupY/VoQbdAmQTT4XFUYm6feGFF2TBOvnkkz/++OM9e/asWLFCfymq+0gHOUtakoWhiWs3ieuj22ua/rUc5UV1h9KiO7z77rt696677tItq1atsvqY15GWBN326NFj9+7dc+bMkZaaeHNojj322LjObqO0JH960k3vLlmyRFoWLly4c+dO2a0pTLfWFxjyp1Lmn3DrdtnWHdxxsf48Tb5117ufffaZ3r3wwgvNbsOHD2/Xrp3a+PDDD3UHRZcuXdR7UT2lpXDdmmONbgGyiKfC4qhE3WqOO+44WbZM9NF169bZB5pJFoYmrt0krs+0adP0IU1tba37u1vTwYrLL79ctqWP2+Lq1uymkT+nqmlNtw3GuaauGjw+PekmLeZ/k0SxfPly2d67d690s1i9erVxUiNyaNCgQdYhjXTQu+64tOy+D/Wjj3SwfhoQtG4V1k8zRx55ZCH/3q31YZpjjW4BskgQhblUrm4Vao3r06dP+/bt27Ztq1b/p59+2jz6yiuvnHLKKcccc8yIESMaCn4+08S1myT0qaurUxdXppk/f35Dvj+VUvTr10/dtjp98eLFDflE5bbk1a16qO3Zs6e6VO/evb/99lv5903PPPNM6ROHvMTs2bOtQ6V9etJNWhqa/qVe9eNFhw4dZsyYEdfHZezYsSeeeGJc5169eqmn8yOOOOKyyy6bMGGCeUj3d8dl6dKlo0ePPuuss9Rnpd6XerpVLVYfxUMPPXT66aernz9UXVlXbmj6tHv06NGmTZvp06c3xPxXpdwbaPXDBIAMEUphFhWtW3CRpVz+jdIEpLN9IDXGjBlT/hcFAAhISgpDt5WOenB8++236+vrN27cWNQ3yfLfbejbt699LBzq+qNGjVq/fr168n7jjTfk9twHRwCATJCSwtBtpSMC0xx00EEJ/7UKzdKlS6X/E088YR8OinFr++jZs6fdCQAgO6SkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgqrXN2+BgAA8diLZpHkpvyoymK/w1IJojCXYPcnBNGt1FM9AAA4+EjXFVXVxH6rJeGvsLyEuTkTf90iWgCAQijNuK6lqin2uy0eT4XFEeDOLDx1i2sBAAqnWN26fqq+2O+5SHwUloDvbbn469auJgAAiKHYB1xXTtUX+z0XiY/CEvC9LRd0CwBQTgrXrWumao39zovBR2EJeN1TXtAtAEA5Qbdu7HdeDD4KS8DrnvKCbgEAygm6dWO/82LwUVgCXveUF3QLAFBO0K0b+50Xg4/CEvC6p7ygWwCAcoJu3djvvBh8FJaA1z3lBd0CAJQTdOvGfufF4KOwBLzuKS/oFgCgnKBbN/Y7LwYfhSXgdU95QbcAAOUE3bqx33kx+CgsAa97yks5dbthw4a+ffvarelwxx13LF++3G5tJvk2xowZozeef/75fv36tTzoi9zYiBEj7GPFU+AbKRy5oN4w73blypVGRwAokbLptqYla8f/2D20/YV9LZ1O+z9G30beGf3PZmf3+gFjv/Ni8FFYAl73lJf9pdsHHnigf//+9957rxxVh9TKftNNN/3yl7+Uxk2bNt1yyy0TJkxQ5nvxxRd147PPPqvO1Y265c033xw+fPigQYPkRH/dPvHEEwMHDtQtmzdvznvDixcvVn3mzJkjjW43ddvXXXfd7bff/tFHH9U339g777zTt5n65uur+3/vvffiTsxLIW9EUK+iPyV5la1bt955553qVR577LHdu3fXx+tW7nbmzJn1BbxNAIijPLrtfNa/Kkc+N/S/Sktds243TPwndejEo/9N/XNo1/+pG7Vue57zv9T2thcaFdu19l/1IXQbhv2l2xUrVuRyuZdeeslc35Uetm3bNmnSpE8//VQaFy5cqOWkdTty5MihQ4du375dN+puU6ZM2bhxY11dnbR46vahhx4y5T1+/Pi8N3zPPffoNyUCs7rNmjVL/biwZcsWdW9KUfUxT7f6+qrPgAED1PvNe2JeWn0j5q56Ff0pyauo0xcsWLBjx4758+frz9x8d/XxT7etvk0AiKM8uk1wZJefNZq47tkfm31c3f6mz39r9VKhYr/zYvBRWAJe95SX/aVbwVrfNRMnTlT/nDp1qtKeblGPZVq3ZjfVKNuaULpVHZYsWWIfaMK94fXr17sX1C3qLaincLM9r26FdevWqR8m6vOdmBf3dU30G9GsWbNG2uVV3NOtdxenWyHubQJAHGXTbftjfuK260Nan3pj3YR/yjlfJh99+L+7/dOL/c6LwUdhCXjdU172l25FA9b6rnnqqafqm76xfP3113WLWs1d3coS717NU7fqIbtv05fbumXcuHHuS5gXMRutbqNGjVLb/fr1U0+E9TG6zXt968S8SOe8WE+37quoO9HbDz74oO4jF9Qbcbq1rlNf2N0CQH0Zddv20P9w2xeN/c+izws7Nir28rMavzS2dHvKsT8xL6X7pxf7nReDj8IS8LqnvOwX3Yomd+/eba3vGq3bZcuWXXvttXJUdGt+1VzfdLVJkyaZLfXeutUbd999t/5KWfpbN6ysXN90A+rl9IbbTdAtcmN33XWXdUjx8MMPx52Yl4RD9Y5uE15l7ty5+n7Md1ff8m7ll7KFvE0AiKM8utW/u5007L9Ii/7drelUIdfyy+SvJ/0ntX3qcT/RJ0qf9GK/82LwUVgCXveUl/2i21wu19dAHzWXaa1bxZAhQ3SfRx555KWXXlIt+he00lgfc7Uguq1v0szgwYPVP92XcFvcOzG/zr3lllvqjRtbsGCBdJPrT548Oe7EvOjOcVi6dV9FXkKxbt063aI76w33bmfOnFnI2wSAOMqj25xj1rXjf7zl+UaP1hjuPKLtv6vdu3r/d1O3cq7+u2XrlDRiv/Ni8FFYAl73lJdy6taHO++8c9GiRW6j1VIgWhKeBLmIJ5VwDwBQFGXTrcqIHv/juCP+7fA2/3HNBf+idvuc/y9KnGed/H+lw5sj/1nb1NJtuyYNX3bm/86h21BUuG4ff/xx9UysXkW8smrVqsWLF+/cudNsLJaSTzQJchFPKuEeAKAoyqnbrMR+58Xgo7AEvO4pLxWu27lz5w4fPvyee+7J5XK6ZdeuXWPHjh0wYIDZWCxBLBXkIp5Uwj0AQFGgWzf2Oy8GH4Ul4HVPealw3QIAVBno1o39zovBR2EJeN1TXtAtAEA5Qbdu7HdeDD4KS8DrnvKCbgEAygm6dWO/82LwUVgCXveUF3QLAFBO0K0b+50Xg4/CEvC6p7ygWwCAcoJu3djvvBh8FJaA1z3lBd0CAJQTdOvGfufF4KOwBLzuKS/oFgCgnKBbN/Y7LwYfhSXgdU95QbcAAOUE3bqx33kx+CgsAa97ygu6BQAoJ+jWjf3Oi8FHYQl43VNe/HWLcQEACkSvmfZKGo9rpuqL/Z6LxEdhCfjelounbht4wAUAKIxiXatx/VRNsd9t8XgqLI4Ad2YRRLcau7IAAKCZ0lzbgG5bw1NhcQS4Mwt/3WpEugAAkBd73SwY11JVEPtNlkoQhbkEuz8hlG41dnEBAICHaE1cY2U39nvzIKDCTELeoiasbgEAAMpJSgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgqrXN3Of+cfpApij2to3FckmYs9qKFxX5FkMfa4pkYQhblUqG71h5vb9j3JdFKdJBRJdSTtxZQ6qY6kWiQW/grLSyXqlulRTUlvklAk1ZT0ioQ6qZqkt5hYeCosjorTLdOj+pLGJKFOqiwUCSkkwYskLz4KS6ASdet+xCTrCTtJWEarMmGLpIHFpEoTvE5cfBSWALol5UjYZxeKpFoTtkiok6pMwCKJw0dhCaBbUo6gW1JIwhYJdVKVCVgkcfgoLAF0S8oRdEsKSdgioU6qMgGLJA4fhSWAbkk5gm5JIQlbJNRJVSZgkcTho7AEsqTbT/+2i1R43FGTGRJwklAkWY87cFIn9mCXSoJu3fshFRh34IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLAN2SkHFHTWZIwElCkWQ97sBJndiDXSroNutxBy54kcTho7AE0C0JGXfUZIYEnCQUSdbjDpzUiT3YpYJusx534IIXSRw+CksA3ZKQcUdNZkjASUKRZD3uwEmd2INdKug263EHLniRxOGjsATQLQkZd9RkhgScJBRJ1uMOnNSJPdilgm6zHnfgghdJHD4KSwDdkpBxR01mSMBJQpFkPe7ASZ3Yg10q6DbrcQcueJHE4aOwBNAtCRl31GSGBJwkFEnW4w6c1Ik92KWCbrMed+CCF0kcPgpLIEu6JdlN2XRLMp2wRUKdVGUCFkkcPgpLAN2ScgTdkkIStkiok6pMwCKJw0dhCaBbUo6gW1JIwhYJdVKVCVgkcfgoLAF0S8oRdEsKSdgioU6qMgGLJA4fhSWAbkk5gm5JIQlbJNRJVSZgkcTho7AE0C0pR9AtKSRhi4Q6qcoELJI4fBSWALol5Qi6JYUkbJFQJ1WZgEUSh4/CEkC3pBxBt6SQhC0S6qQqE7BI4vBRWALolpQj6JYUkrBFQp1UZQIWSRw+CksA3ZJyBN2SQhK2SKiTqkzAIonDR2EJoFtSjqBbUkjCFgl1UpUJWCRx+CgsAXRLyhF0SwpJ2CKhTqoyAYskDh+FJYBuSTmCbkkhCVsk1ElVJmCRxOGjsAQyqduaZtq2bXvpJZ0/Wvw3t08506ZNG30/7iGiU37dDrl5mBqR11+d4x7KG9W5W7eebrvk09XrzVFesWyNNeit1kCrL0HCFkkhdVL3xRY1KGolOemkk9XGsqWfun0Kz/K/RlVx7rnnM+JpJGCRxOGjsASyrVth8qRpbreyRW5j29bv3KMkVxW61X0UG9ZtU9u3DBmud2e//me1+/vnpupd9yzz9FZf4gBP2CIppE70qAkjRtyp2yc8O1ntKn26pyQE3ZYhAYskDh+FJZBh3ept/WR50EEHud3Kk5H3jFE3cOihh6p/DrpxiNuB5KpLt6NG3qu2Vcnp3a5duqvdM844U2136nShe5Z5eqsvcYAnbJG0Widfb65XgzL2oUel5YH7H9Yb/rolKSVgkcTho7AEMq/bjh3PUNvt2rVzD+nt6dP+qLZvuP4mvavp0b2X7qN/Ar3hhsFySF7l5sG36pa2bdvqjSefmGDehvkqL0x+yTqdmKkc3ephEjauz0n7ZZdeLu2v/vEt95rXXNO/prEeDtP9T+vQUXeWy+pimzH9tebLNLLlq915X+Kwww53X+IAT9giabVOPl+zSQ3ERRddarUPGHCDDJPi57Vn55qG75Yhw3UH3a63t239Vno+9OCjcsh6uj3qqKOl24knnmS9Iik8AYskDh+FJZBh3Qqqjq1D5rZeAc38deknqn3KCzNyzVNCyVJtq6VZbT/15ES1rX7gdS/l6nbS8y9KN73x4AOPWH1IrpJ0a0bGzto+//wL1LZai63+//h638L61ptz1T+XfLTq3jEPqY0N67fL6Xkrx92Oe4kDPGGLpJA60YMizHrlDd3uPt2q3WG33m6e5W5f1aev7Jq61Y2PjxvvnkKKTcAiicNHYQkcKLpV8yQ6oQm1UOaap4Tu/8nf16lt/W3SBRdcpLaPOeYY81Kubg8++OCapodjtT1q5H26m9WH5CpGt9v/sUePkYk+pDYuvOBivT3zlT+p3WefmeReVp/Ss0dvfeJXG3eqjd+Oul8uVVt7tt42ee3Vtwt/iQM5YYukkDpR+eKzr3511z2HHHKIHizdmFe38ptds6e5vWD+Utl1dWteytwlRSVgkcTho7AEMqxbc/vqq66NO6R1q7fVk+u2rd+uXlVXk0+3n326saZZt336XONeytWtbreQLw+JpEJ027VLd9XYpk0bNdY5p1qOP/4Eva2eQtSuMqJ7WVmUzRMPO+xw9c9rru6ndrt36yUdhN8/N7XwlziQE7ZICqkTM3oc9XZe3d40aN8fZ+hhdbfl9wi5fLrdsH67ewopNgGLJA4fhSWQed3+buxj5q7efuThJwbdOERvm7pVk0Gts4cf3jipknWrn3QVmzft/M3do/V2Xt2af6V15JFHqZZfXHm11Y1UiG71r07VqqqeSp94/Fk9rPqQ3p79+p+tf+HHinoM0ke7XNFNt8jfTM2bu1jtftb060DFKy/P3rrlm7ffmndl76uKeokDOWGLpJA6Oa1DR1UkX2+un/P2++ag/HHWm2r77l//VnrWNE32dXVbZW3R7fonMLXOrP18s27Xh0zdtmvXTm0fecSRmzbsUMuI2j6l/U/dmyGFJGCRxOGjsAQyr1uVE044Ue2q2aK21QJ3/nkXqPW07ostupvWrXqoveCCi9q2PUxNFT0rknWro6bKaaedvnL5Z/pS+te9Ev17mgXzl0rLF599pXua3Uhu/+nWpGPHM1S7sqz6eatDh9MWf7hCt+v+NU0r47QXZx133PHJS6E+S55UVFWY19EZ/8zzp57a4dBDD+3RvZco33qJFcuK+6vXAyFhi6SQOlHz/ZxzzmvTps1RRx193cAbzUNPP/Wc/llq3KNP55rWFlU5tbVny9oiPadNndm2bdtbh96W8C8Cfbl2a88evVW39u1PUdK1boMUnoBFEoePwhLIpG7LE6Xtv7z7oVpVhw4d4a6npKiUX7ckiwlbJNRJVSZgkcTho7AE0G1stGKFue8tcvuQAoNuSSEJWyTUSVUmYJHE4aOwBNAtKUfQLSkkYYuEOqnKBCySOHwUlgC6JeUIuiWFJGyRUCdVmYBFEoePwhJAt6QcQbekkIQtEuqkKhOwSOLwUVgC6JaUI+iWFJKwRUKdVGUCFkkcPgpLAN2ScgTdkkIStkiok6pMwCKJw0dhCaBbUo6gW1JIwhYJdVKVCVgkcfgoLAF0S8oRdEsKSdgioU6qMgGLJA4fhSWQSd3Om7u4czO65ebBQ/TugvlL3P5kv6f8uu3Vq7dVJLJ75ZW/cPuTSkjYImm1Tma//o5UxbK/fqpaNm3YIS0sJpWZgEUSh4/CEsikbtVM+Hpzvexu3rSzc9OSunVLvd4glZby61bSv//Av7z3odmiimTt55vdnmS/J2yRFF4ny5Z+opeObt26LV60IsdiUsEJWCRx+Cgsgezp9s033ruqz77/5rvO5Ekv/m7so3rbnSGXX365/ln1vT8vULt1X2y5adBgtfvAA7/T/TUbm/4TuOrobbfdoVvuuONXquW5iS/o3e7dund2Lk4KzP7S7d9WfO6OmmrZ/o89Zsv0aTP1KHftuu9/PKCLRJ/b95pr9fbAgddbR3UHfU2rhZSQsEVSeJ2sXlWnRjnXcgFxh1KGWC8mauPWocM7Ny0mUiSdmxcTtSGLiT5dFpN7xzw4Y3rjf8udlJCARRKHj8ISyJ5uJzw76bej7tVVe/31N6qWRx4ep4yrj0pl6zw+7plRI8fkmv7H4PqQEqrVJ9f0DZJaQPXRJR+vMi8lnTeuz7knkgKzX3R7e9Nid+edvzYbH3lk3P33jbV6ysjecMOgl2e8ZraYueKKLlb/x8c9/eLUV8Y99tTYh/6fdYiUkLBFUmCd5IxRM4fPXUz0hiwm6p/6fwNlRhYTdVQWE1Uk5gX79LkK3ZacgEUSh4/CEsiebmfNfMOaGwlPt4MGDV6x/DPzkBLqzTffolu++Oyrzs3oxxp1VM6VGWW1kBKyX3Src++YB37/3JTm7QfHjL7f7SMj+9abfxk5crTakCJRufrqa6ROdMuQIUP1xuzX33nm6eduvPGm1X//0roUKSFhi6SQOtHu3Lb1W72bMN8HNUnUPGR2MItELybmUVUkZot6zEW3JSdgkcTho7AEsqfbXFPVqh8q33zjPSlftbF1S71aKPU3QhLlWnVo1d/W3nXX3b169co1CVXWSvVEMmrUvZ+v2dS7d+843V5++eXPPD1x86adw4aNMOcPKSrl1+0D949d88n6Dxf8tXPzQ4a5XFpRo6yK5K9LV6vOG9ZtyxlCze2rrm/U+igFYOlWnaiu8Onq9R8tWkmR+CRskbRaJ2s/3/zkE8+aLY899tS11/aLW0we/t2jmzftksXEHGu1vXpVnbmYuLqVxUQdQrclJ2CRxOGjsAQyqVv1o+jgwUNUtmzerVtUBXft2nX0b+9zO3/w/se/+MUv1GON3jV1q/LrX92jVuFtW7+L022uaW3t3fvKFcvWsJKWnPLrds7b864beP3119+4bOknuqWzwfz3P7L6qyJRDyj6z1NzLXWrbN29W/epU2aoPtZRrdvGjdfmdOvW7Td3j6JIfBK2SFqtkxcmTzOrQjeOH//7uMXk7rtHXnFFF1lMzLFWRdKnz1XmYmIe1UWSa15MlLbffmuudXFSYAIWSRw+Cksgk7otZ2bN/JNar9fVbR06dJh6wHU7kEJSft2WORMnTFY/870/dzFF4pOwRVJpdSKLCT+T+SRgkcTho7AE0G0r2bRhx9Bbhqmfdh95eJx7lBSYqtft5Ekvqmff/v0HuodI4QlbJJVWJ7KYrPl0g3uUFJiARRKHj8ISQLekHKl63ZIgCVsk1ElVJmCRxOGjsATQLSlH0C0pJGGLhDqpygQskjh8FJYAuiXlCLolhSRskVAnVZmARRKHj8ISQLekHEG3pJCELRLqpCoTsEji8FFYAuiWlCPolhSSsEVCnVRlAhZJHD4KSwDdknIE3ZJCErZIqJOqTMAiicNHYQmgW1KOoFtSSMIWCXVSlQlYJHH4KCwBdEvKEXRLCknYIqFOqjIBiyQOH4UlgG5JORJ2hrCSVmXCFkkDi0mVJniduPgoLAF0S8qRsDME3VZlwhZJA4tJlSZ4nbj4KCyBitNtA5Ok6pLG9MC4VRY9oPYwe0ORVFnSKBIXT4XFUaG6ZTGtjshQ2mMcAoqkakKRkFaT6mJi4amwOCpRtxrmSdZThrkhM9B9dZKJlGcNpUgynfIUiUkQhblUrm4bjMWUZDT2iKaA+6IkW7FHNB3c1yXZij2iaRJKYRYVrVsAAIAyk5LC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgpDtwAAABEpKQzdAgAARKSkMHQLAAAQkZLC0C0AAEBESgoLr9uG1O4VAAAgVdJ7YkxRt2ncLgAAQHqkJ69UdNuAcQEAIGukaq7UdZvSfQMAAAQkbWelpduGlsZN7w0AAAD4UB5bpajbBuc9EEIIIZUcW2PhSFe3Gvf9EEIIIZUT21spUA7dAgAAHOCgWwAAgNRBtwAAAKmDbgEAAFIH3QIAAKQOugUAAEgddAsAAJA66BYAACB10C0AAEDqoFsAAIDUQbcAAACpg24BAABSB90CAACkDroFAABIHXQLAACQOugWAAAgddAtAABA6qBbAACA1Pn/u1c1r2kMa90AAAAASUVORK5CYII=>