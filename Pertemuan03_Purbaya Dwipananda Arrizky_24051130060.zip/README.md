# Pertemuan 3 — Arsitektur Informasi, User Flow, Wireframe, dan Prototipe Awal

**Proyek:** Kampus Lost & Found
**Mata Kuliah:** Praktik Aplikasi Web (INF60295) — Semester 5
**Dosen Pengampu:** Zaenal Mustofa, M.Kom.
**Program Studi:** Teknologi Informasi — S1, Fakultas Teknik, Universitas Negeri Yogyakarta
**Tanggal revisi:** 14 September 2026

## Ringkasan Pertemuan

Pertemuan ini menerjemahkan persona, user story, acceptance criteria, dan backlog prioritas dari Pertemuan 2 menjadi rancangan antarmuka yang memiliki alur jelas, responsif, dan siap menjadi acuan implementasi.

Ruang lingkup yang dipilih adalah **satu tujuan pengguna yang dapat diselesaikan utuh**: mahasiswa menelusuri daftar barang temuan, mengajukan klaim, dan memperoleh kepastian keputusan dari petugas posko. Empat user story berprioritas Must masuk lingkup — US-06, US-07, US-08, dan US-09 — dengan total 13 dari 29 poin prioritas Must.

## Anggota dan Kontribusi

| Nama | NIM | Peran | Kontribusi |
| --- | --- | --- | --- |
| Purbaya Dwipananda Arrizky | 24051130060 | Seluruh peran | Proyek dikerjakan secara mandiri atas persetujuan dosen pengampu. Peran fasilitator, pencatat, penjaga waktu, perancang, dan presenter dijalankan sendiri. |

## Daftar Artefak

| Berkas | Isi | Status |
| --- | --- | --- |
| `01-scope-canvas.pdf` | Scope canvas, alasan pemilihan dan penolakan story, batas prototipe | Selesai |
| `02-sitemap.pdf` | Hierarki sitemap, daftar halaman, pembagian navigasi peran, lampiran inventaris layar dan pemeriksaan keterhubungan | Selesai |
| `03-user-flow-pengguna.pdf` | User flow pengajuan klaim oleh mahasiswa, diagram dan skenario langkah | Selesai |
| `04-user-flow-admin.pdf` | User flow verifikasi klaim oleh petugas posko, diagram dan skenario langkah | Selesai |
| `05-wireframe-desktop.pdf` | Wireframe delapan layar desktop | Belum |
| `06-wireframe-mobile.pdf` | Wireframe lima layar mobile | Belum |
| `07-usability-walkthrough.pdf` | Hasil uji, temuan, tingkat keparahan, dan revisi | Belum |
| `08-keputusan-desain.md` | Sebelas keputusan desain beserta dasar, alternatif, dan alasan | Selesai |

**Tautan prototipe:** *(akan ditambahkan setelah prototipe klik selesai disusun)*

## Daftar Halaman

| ID | Nama Halaman | Peran | Sumber User Story |
| --- | --- | --- | --- |
| H-01 | Beranda | Mahasiswa | Halaman penghubung |
| H-02 | Cari Barang | Mahasiswa | US-06 |
| H-03 | Detail Barang | Mahasiswa | US-06, US-03 |
| H-04 | Form Klaim | Mahasiswa | US-07 |
| H-05 | Klaim Saya | Mahasiswa | US-07, AC-09.4 |
| H-06 | Daftar Klaim Posko | Petugas | US-08 |
| H-07 | Detail Klaim | Petugas | US-08, US-09 |
| H-08 | Not Found | Semua | Halaman utilitas |

Delapan layar desktop dan lima layar mobile. H-06, H-07, dan H-08 tidak digambar dalam versi mobile karena persona petugas bekerja menggunakan komputer desktop di meja posko.

## Di Luar Ruang Lingkup Pertemuan 3

Seluruhnya merupakan keputusan sadar, bukan kelalaian. US-01, US-13, US-15 registrasi dan autentikasi; US-02 pelaporan kehilangan; US-03 dan US-04 formulir pelaporan penemuan; US-05 pencatatan barang titipan posko; US-10 penandaan barang sudah diserahkan; US-12 pencocokan otomatis; US-14 rekap barang belum terserahkan; US-16 komunikasi petugas dan penemu di dalam sistem.

Acceptance criteria yang tidak masuk pemeriksaan keterhubungan — AC-01.x, AC-02.x, AC-05.1, AC-05.2, AC-05.4, AC-10.x, serta AC-X.1 sampai AC-X.3 — merupakan milik story di atas dan akan dirancang pada pertemuan berikutnya.

## Catatan Penggunaan AI

Disertakan atas inisiatif penulis agar batas antara pekerjaan penulis dan bantuan perangkat AI dapat diperiksa secara terbuka, melanjutkan praktik yang sama pada Pertemuan 2.

| Aspek | Keterangan |
| --- | --- |
| Perangkat AI | Claude (Anthropic) |
| Bentuk bantuan | Membaca modul praktikum dan artefak Pertemuan 2; menyusun draf lembar kerja berdasarkan keputusan yang ditetapkan penulis; menandai celah rancangan untuk diputuskan penulis; menggambar diagram user flow; merapikan bahasa dan format dokumen |
| Keputusan yang ditetapkan penulis | Pemotongan ruang lingkup sampai proses pengajuan klaim; beranda berbentuk penghubung dengan dua pintu berporsi sepadan; penetapan bahwa formulir pelaporan penemuan merupakan halaman tersendiri, bukan state beranda; keputusan tidak menarik US-03 dan US-04 masuk lingkup |
| Batas bantuan AI | Seluruh keputusan rancangan ditetapkan penulis. AI tidak menetapkan keputusan produk. |

## Riwayat Commit yang Disarankan

```
docs: add scope canvas and sitemap for pertemuan 3
docs: add user flow for mahasiswa and petugas
docs: add design decision record
```
